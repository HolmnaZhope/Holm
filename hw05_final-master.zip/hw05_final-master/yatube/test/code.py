# code.py

def series_sum(incoming):
    """Конкатенирует все элементы списка, приводя их к строкам."""
    return ''.join(str(i) for i in incoming)
